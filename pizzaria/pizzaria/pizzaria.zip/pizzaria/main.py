import database
import gui

if __name__ == "__main__":
    database.criar_tabelas()
    gui.criar_gui()
